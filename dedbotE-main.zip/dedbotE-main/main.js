const Discord = require('discord.js');
const client = new Discord.Client();

client.once('ready',()=>{
    console.log('dedbot is die');
        
    client.user.setActivity('Die',{type: 'PLAYING'}).catch(console.error);
});
 




client.on("message", message => {
    if (message.content === "die") {
      message.channel.send(
        "https://media.discordapp.net/attachments/760420833033453578/811473399364190258/magik.png?width=187&height=225"
      );
    }
  });

client.on("message", message => {
    if (message.content === "DiE") {
      message.channel.send(
        "https://media.discordapp.net/attachments/760420833033453578/955759985474797598/magik.png"
      );
    }
  });

client.on("message", message => {
    if (message.content === "Dienos") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/800630249850798120/955769191737217054/Tru_Dienos_and_the_dielet_of_DIEness.png"
      );
    }
  });

client.on("message", message => {
    if (message.content === "nite pic") {
      message.channel.send(
        "https://images-ext-2.discordapp.net/external/B2IUBIvV4-jbiAy1LBR1IPRSV_YsrMDQtVBM4B2rCeo/https/media.discordapp.net/attachments/760420833033453578/879421380767154196/ba71ccd5e4b08173673900b762561833.png"
      );
    }
  });

client.on("message", message => {
    if (message.content === "Ee") {
      message.channel.send(
        "https://media.discordapp.net/attachments/760420833033453578/867765632682688542/New_agrEEd.gif"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "e") {
      message.channel.send(
        "https://media.discordapp.net/attachments/701420137768812565/911531012947865640/wideEgrEEd.gif"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "E") {
      message.channel.send(
          "https://cdn.discordapp.com/attachments/760420833033453578/943022963979067472/TALL_E.png"        
      );
    }
  });


 
  
  client.on("message", message => {
    if (message.content === "weeknd") {
      message.channel.send(
        "https://media.discordapp.net/attachments/800630249850798120/808587332222976020/unknown.png?width=101&height=104"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "lmfao") {
      message.channel.send(
        "https://media.discordapp.net/attachments/802898412068012042/810158811063123998/unknown.png?width=137&height=131"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "LMFAO") {
      message.channel.send(
        "https://media.discordapp.net/attachments/802898412068012042/810158811063123998/unknown.png?width=137&height=131"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "DIE") {
      message.channel.send(
        "https://media.discordapp.net/attachments/701420137768812565/911549893502459924/TALL_die_zap.png"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "dedgeng") {
      message.channel.send(
        "https://media.discordapp.net/attachments/760420833033453578/828524903724613642/WE-R-DED-GENG-FULL.png?width=888&height=500"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "Dedgeng") {
      message.channel.send(
        "https://media.discordapp.net/attachments/760420833033453578/828524903724613642/WE-R-DED-GENG-FULL.png?width=888&height=500"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "sus") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/920235647703334953/unknown-1.png"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "Sus") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/920235647703334953/unknown-1.png"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "fat neek") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/911653179970682980/IMG_20210225_224512.png"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "where mask") {
      message.channel.send(
        "https://media.discordapp.net/attachments/701420137768812565/810156953975652362/where_mask.png?width=888&height=500"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "allah") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/922841838837190676/b68d3a71953dab48e65d3fedff24c1b9a7ec927e7bdf78cb923790ddd3769275_1.jpg"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "soba") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/922841838338048032/Sova.mp4"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "WE") {
      message.channel.send(
        "https://i.kym-cdn.com/entries/icons/original/000/034/467/Communist_Bugs_Bunny_Banner.jpg"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "diamonds") {
      message.channel.send(
        "https://tenor.com/view/sb737-minecraft-diamonds-gif-22360397"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "lets go dababu") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/748507840985038918/921102216545316864/IMG_20211114_190014.jpg"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "gm") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/753872269272547429/927775224882143252/Zap_HI.gif"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "Gm") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/753872269272547429/927775224882143252/Zap_HI.gif"
      );
    }
  });
  
client.on("message", message => {
    if (message.content === "GM") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/753872269272547429/927775224882143252/Zap_HI.gif"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "kinsmen") {
      message.channel.send("oP bHaI");
    }
  });
  
  client.on("message", message => {
    if (message.content === "platinum") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/911165904841236500/nuo24tl3b0l71.png"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "where E?") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/903329369022431242/meme.png"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "vine boom") {
      message.channel.send("https://bit.ly/33FUXPH");
    }
  });
  client.on("message", message => {
    if (message.content === "Vine boom") {
      message.channel.send("https://bit.ly/33FUXPH");
    }
  });
  
  client.on("message", message => {
    if (message.content === "Taiwan") {
      message.channel.send(
        "ATTENTION CITIZEN! 市民请注意!This is the Central Intelligentsia of the Chinese Communist Party. 您的 Internet 浏览器历史记录和活动引起了我们的注意 YOUR INTERNET ACTIVITY HAS ATTRACTED OUR ATTENTION. 志們注意了 you have been found protesting in the subreddit!!!!! 這是通知你，你必須 我們將接管台灣 serious crime 以及世界其他地方 100 social credits have been deducted from your account 這對我們所有未來的下屬來說都是一個重要的機會 stop the protest immediately 立即加入我們的宣傳活動，提前獲得 do not do this again! 不要再这样做! if you do not hesitate, more social credits ( -11115 social credits )will be subtracted from your profile, resulting in the subtraction of ration supplies. (由人民供应部重新分配 ccp) youll also be sent into a re-education camp in the xinjiang uyghur autonomous zone.为党争光! Glory to the CCP!"
      );
    }
  });
  
  client.on("message", message => {
    if (message.content === "mha") {
      message.channel.send(
        "https://tenor.com/view/ksi-suspicious-face-ksi-face-funny-gif-21792353"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "bruhhhh") {
      message.channel.send(
        "https://cdn.discordapp.com/emojis/750594492817735682.png?size=44"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "sadgness") {
      message.channel.send(
        "https://cdn.discordapp.com/emojis/766307279599304704.png?size=44"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "fk school") {
      message.channel.send(
        "https://fkschools.sc.tz/wp-content/uploads/2019/04/fklogowebsite.png"
      );
    }
  });
  client.on("message", message => {
    if (message.content === "HI!") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/909018842695618560/images_3.jpeg"
      );
    }
  });

client.on("message", message => {
    if (message.content === "Die") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/925282468351852554/IMG-20211209-WA0000.jpg"
      );
    }
  });

client.on("message", message => {
    if (message.content === "murica") {
      message.channel.send(
        "https://tenor.com/view/fat-man-shoot-gun-murica-usa-gif-11611613"
      );
    }
  });

client.on("message", message => {
    if (message.content === "UwU") {
      message.channel.send(
        "https://tenor.com/view/cj-uwu-running-running-back-gif-17502373"
      );
    }
  });

client.on("message", message => {
    if (message.content === "Roti man") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/753872269272547429/927831588690079814/Roti_man_is_here.png"
      );
    }
  });

client.on("message", message => {
    if (message.content === "go touch some grass") {
      message.channel.send(
        "https://media.discordapp.net/attachments/760420833033453578/919861950500991006/IMG_20211213_121411.jpg?width=419&height=559"
      );
    }
  });

client.on("message", message => {
    if (message.content === "Go touch some grass") {
      message.channel.send(
        "https://media.discordapp.net/attachments/760420833033453578/919861950500991006/IMG_20211213_121411.jpg?width=419&height=559"
      );
    }
  });

client.on("message", message => {
    if (message.content === "JEWS") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/928699816471572531/JEWS_chased_by_shark.png"
      );
    }
  });
    
 client.on("message", message => {
    if (message.content === "pass some bleach") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/928699816878407700/Shots_of_bleach.png"
      );
    }   
     
  });

 client.on("message", message => {
    if (message.content === "where roti?") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/753872269272547429/928897855173828628/Where_roti.png"
      );
    }   
     
  });

client.on("message", message => {
    if (message.content === "Where roti?") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/753872269272547429/928897855173828628/Where_roti.png"
      );
    }   
     
  });

 client.on("message", message => {
    if (message.content === "WE should DIE") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/932844104302333952/WE_Should_DIE.png"
      );
    }   
     
  });

client.on("message", message => {
    if (message.content === "pass some food") {
      message.channel.send(
        "https://tenor.com/view/of-to-gulag-gif-19230867"
      );
    }   
     
  });

client.on("message", message => {
    if (message.content === "Africa") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/933935482562306048/IMG-20220117-WA0003.jpg"
      );
    }   
     
  });

client.on("message", message => {
    if (message.content === "africa") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/933935482562306048/IMG-20220117-WA0003.jpg"
      );
    }   
 });
    
   client.on("message", message => {
    if (message.content === "diE") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/942021324920983562/ShpntdybI9TbL4qYdTd4TlsqEnih31clZV860MzW_CkcHmDfz5ICRZ-1rK-Jib1kqQPV-n-a-UwKnI1A33Lm7Xa1K1yGRfKfXFyDeDZ2tGxABRlAv6SAaBHS8KUb9Wr9x5IkwB3O5X8VE--YxjyeN8wAHNp_ddCJc9xBzReoVzFKCkBeCAO_hbbhoTcGpgtiCRGwy0wr8N0uneW2WMQi4D23RA0RJF9swb9GkNB_Y0PysgIruo4jXeUmAlrdjXRhlfbXOy60PsQCv0aiNvgmmLCRIp7s50m3Ff5ANs1yzA8BT5nXURc8aeCrLUsK1Mtnq9pv7BEeiiPFgOEwSYGoKEUEZT33TLQ_miVKH_r5NC1TJw_HwkJVdy455ySU9GQmHxyFXgjW_p7VqCsKbwxOqsd8lWNyu7I5t5IAiM97XsWBrCcjD-NQF6BW6g-Ug4T9fT_EHz_8NSY75uxRO7RUGQPZWVRyymVBgXbhtCa5Bx-C8BhPLnQZh1U-MG7s..png"
      );
    }
  });
     
client.on("message", message => {
    if (message.content === "Donald") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/942989081565089852/Donald.mp4"
      );
    }
  });

 client.on("message", message => {
    if (message.content === "Æ") {
      message.channel.send(
          "https://cdn.discordapp.com/attachments/787678081594163232/943023360269500416/art.png"        
      );
    }
  });
 
 client.on("message", message => {
    if (message.content === "afk") {
      message.channel.send(
          "https://tenor.com/view/uwu-glitch-dance-dancing-moves-gif-17079160"        
      );
    }
  });

client.on("message", message => {
    if (message.content === "dIe") {
      message.channel.send(
          "https://cdn.discordapp.com/attachments/760420833033453578/946768751863402576/new_die_face.png"        
      );
    }
  });

client.on("message", message => {
    if (message.content === "Hei") {
      message.channel.send(
        "https://media.discordapp.net/attachments/760420833033453578/952884628270759956/redditsave.com_disey_moment-1988d5vfl8n81.mp4"
      );
    }
  });

client.on("message", message => {
    if (message.content === "hopefully") {
      message.channel.send(
        "https://cdn.discordapp.com/attachments/760420833033453578/967795915727466636/hopefully.png"
      );
    }
  });



client.login('Z6RFKHDHIRCPFXD7D5PKXIAP545BAPBW7T5LP2FBIZXF4OEBUP7W5PIARM');
